# V8：每种 SB 的收敛曲线与禁忌搜索说明

## 已有 V7 结果可以直接加图

不需要重跑算法。在V8根目录的MATLAB命令窗口运行：

```matlab
clear functions
addpath(fullfile(pwd,'matlab'),'-begin')
rehash
source='D:\code\LEO_QoS_Comparison_v7\results\comparison\seed_71669974\benchmark.mat';
run_leo_sb_convergence(source);
```

支持benchmark.mat、raw_benchmark.mat、plot_data.mat或对应结构。默认输出在输入MAT所在目录的sb_convergence子目录。若实际种子目录有_run_2后缀，请选择那次实验的文件。旧plot_data若没有理论界，只画已有轨迹，不从别的实验补界。旧日志无法恢复未记录的中间时刻。

## 图和数值

默认14项方法中包含8项SB方法/消融，每项各一张2×2图：

- 已保存的保证服务随实际核算耗时变化。全员门槛启用时，尚未全员达标的吞吐点留空；上界、证书阶段可行下界作为事后参照，未提供给被测算法。
- 已保存的最差用户保证QoS比例随耗时变化。初始化已达标时，公平曲线平在1是正常结果。
- 原始保存服务随外层价格轮数变化。不同阶段、portfolio成员的计数分别从零开始，不能把它们的原生轮数当作相同工作量。公平阶段提高最差用户时，总服务允许下降；不使用cummax伪造单调性。
- 一个代表性固定Ising调用的离散历史最好能量：各轨迹的最小、中位、最大值。优先选吞吐阶段首个有记录的调用，并标注成员、阶段、块号和价格轮数。能量在修复/polish之前记录；每轮的J、h、惩罚和价格会改变，不能拼接不同调用的能量，也不能比较不同问题的能量绝对值。

另有sb_convergence_comparison，比较全部SB与同场景禁忌、自适应局部搜索的时间曲线。时间轴包含共同物理建模和初始化成本，保留真实停止时刻，不将停止后的曲线延伸到统一预算终点。阶梯线表示已记录检查点，并不补造内部未记录的改进。

文件名例如：sb_convergence_price_sb、sb_convergence_price_sb_blockwise、sb_convergence_price_sb_adaptive、sb_convergence_price_sb_light、sb_convergence_sb_reference_portfolio。导出PNG/PDF/FIG及sb_convergence_time.csv、sb_convergence_rounds.csv、sb_convergence_energy.csv、sb_convergence_specs.json。

默认代表种子为第一个指定种子，不选择最好种子。portfolio整体曲线仅使用已完成成员的保存结果；各成员的内部外层迭代单独标注。没有执行的阶段或缺失的内层能量日志明确留空，不画零值曲线。

## V8 新运行的日志更细

完整比较默认自动生成以上曲线，不需额外命令。V8在每次逐块原目标验收、整轮价格日程验收、整周期恢复返回及阶段结束时记录已保存解的时刻与性能。价格迭代、SB动力学、修复和禁忌规则保持V7设置；新增日志的成本包含在实际算法耗时内。已有V7结果使用原先较稀疏的轮末检查点。

## 代码里的禁忌搜索

位置：leo_solve_original_search.m和leo_original_neighbors.m。

1. 与所有方法共用初始化、物理场景和全员QoS门槛。当前初始化已达标时直接进入吞吐阶段。
2. 邻域包含单块添加、删除、用户替换，以及两块之间的两用户交换。只重算受影响块的服务，按完整原目标累计量评价，不使用SB代理作评分。
3. 默认每轮最多评价160个合法邻居，局部动作优先占至多120个，跨块动作用剩余额度。最缺服务的用户优先，块的起点逐轮轮换。
4. 禁忌表记录最近改动的用户-块二元位置。代码设tabuUntil(changed)=iteration+5，若某位置tabuUntil大于当前轮则禁用；候选优于历史最好时可赦免。
5. 每轮选最好的可接受邻居，允许比当前解更差以逃离局部最优；历史最好解单独保存。吞吐阶段始终保持全员QoS和硬约束，返回前由原始评价器复核。
6. 默认最多1000轮并受方法时间预算限制。图里画的是历史保存的最好值，不是允许临时退步的当前游走值。

它在32用户/20块场景表现好，是因为目标直接、增量评分快、跨块动作有效，并能暂时退步。价格+SB要通过代理、块内Ising和整周期协调，求好子问题不保证整周期原目标最好。外层服务曲线与固定子问题能量曲线应同时看，不能把全流程改善都归因于SB动力学。

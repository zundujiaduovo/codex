# MATLAB 图窗版：32 用户实验

请解压整个 `leo_satellite_simulation` 文件夹，保留里面的目录结构。

在 MATLAB 中打开下面一个脚本，然后点击编辑器的“运行”：

| 脚本 | 作用 |
|---|---|
| `main_32users.m` | 重新运行 32 用户算法对比，完成后弹出 18 个图窗 |
| `show_32user_plots.m` | 直接弹出包内已有的 32 用户结果图，省去重新计算 |

两个入口都会自动设置函数路径，图窗生成后保持打开。默认不穷举、不自动保存图片、MAT 或 CSV。
新运行的数值留在工作区 `report` 中，图窗句柄在 `figures` 中。可以使用图窗工具栏放大或手动保存。

也可以在项目根目录的 MATLAB 命令窗口执行 `main_32users` 或 `show_32user_plots`。
已有 `report` 时，执行 `leo_plot_benchmark(report)` 可重新打开图窗，不必再次运行算法。

`examples/plots_default/plot_data.mat` 和 `results/plots_default` 中的文件为包内已有结果；
新主入口不会自动改写它们。其他接口和可选保存设置见 `PLOTS.md`，各函数输入输出见 `FUNCTION_GUIDE.md`。

## MATLAB 结构体赋值修复

如果 MATLAB 报“在不同结构体之间进行下标赋值”，请使用本次修复后的源码。
本次修复覆盖汇总、用户/日程 CSV 导出、迭代日志和图表规格中的空结构体追加。
已有其他版本的项目可先备份，再使用随包的修复脚本，仅替换相关赋值语句：

```matlab
addpath(fullfile(pwd,'tools'));
repair_leo_struct_arrays(pwd);        % 自动备份修改的文件；可重复执行
```

脚本要求当前目录是含 `matlab` 子目录的项目根目录。具体验证范围见 [VALIDATION.md](VALIDATION.md)。


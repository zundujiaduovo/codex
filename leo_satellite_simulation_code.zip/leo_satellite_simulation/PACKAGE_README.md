# LEO 卫星仿真代码独立包

本包包含当前工作区的 MATLAB 源码、测试、Python 绘图工具及算法说明。
不包含仿真结果 results/、示例输出 examples/ 和本地 Octave 安装。
文档中引用的历史结果文件需自行运行仿真生成。

快速运行（MATLAB R2018b 或更新版本，在解压目录执行）：
```matlab
addpath('matlab');
model = run_leo_sinr();
test_leo_model();
```
完整入口及测试列表见 README.md，算法与依赖说明见 METHOD.md、VALIDATION.md。
Python 绘图工具需要 numpy 和 matplotlib；MATLAB 基础仿真无需 Python。
MANIFEST.sha256.json 记录原始打包文件的 SHA-256。

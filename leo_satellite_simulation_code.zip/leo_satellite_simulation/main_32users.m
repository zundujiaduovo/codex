% MAIN_32USERS 在 MATLAB 中打开本文件并点“运行”：32 用户对比与 18 个图窗。
% 不穷举、不自动保存；report 和 figures 留在工作区。可用图窗工具栏手动保存。
leoProjectDir = fileparts(mfilename('fullpath'));
addpath(fullfile(leoProjectDir,'matlab'));
benchmarkOptions = struct('exhaustive',false,'makePlots',true,'saveResults',false);
benchmarkOptions.outputDirectory = fullfile(leoProjectDir,'results','benchmark_32');
[report,figures] = run_leo_benchmarks('default',benchmarkOptions);
fprintf('32 用户实验结束。图窗状态: %s；结果变量: report；图窗句柄: figures。\n',report.plotStatus);

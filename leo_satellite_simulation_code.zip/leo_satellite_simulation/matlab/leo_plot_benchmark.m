function [files,figures] = leo_plot_benchmark(report,directory,saveFiles)
%LEO_PLOT_BENCHMARK 完整对比图入口：迭代、收敛、性能、资源及代理诊断共 18 图。
% 输入：报告或 plotData；可选目录、saveFiles=false；输出：文件路径（默认空）、图窗句柄 cell。
% 默认只显示并保留图窗；第三参数 true 才保存数值和 PNG/PDF/FIG。
if nargin<2, directory = ''; end
if nargin<3, saveFiles = false; end
[files,~,figures] = run_leo_plot_results(report,directory,true,saveFiles);
end

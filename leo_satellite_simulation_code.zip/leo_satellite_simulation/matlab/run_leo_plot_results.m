function [files,plotData,figures] = run_leo_plot_results(source,directory,render,saveFiles)
%RUN_LEO_PLOT_RESULTS 从已保存结果重画全部图，无需再次运行优化算法。
% 输入：MAT 路径或报告结构；可选目录、render=true、saveFiles=false。
% 输出：files（默认空）、plotData 数值、figures 图窗句柄 cell；默认弹窗并保留，不写文件。
% render=false 仅整理数据；需导出数据时显式传入第四参数 true。
if nargin<2, directory = ''; end
if nargin<3, render = true; end
if nargin<4, saveFiles = false; end
assert(isscalar(render) && (render==0 || render==1));
assert(isscalar(saveFiles) && (saveFiles==0 || saveFiles==1));
if ischar(source) || (isstring(source) && isscalar(source))
    saved = load(source);
    if isfield(saved,'report'), source = saved.report;
    else, assert(isfield(saved,'plotData'),'输入 MAT 中需要 report 或 plotData。'); source = saved.plotData; end
end
if saveFiles
    if isempty(directory), directory = fullfile('results','plots'); end
    [plotData,specs] = leo_export_plot_data(source,directory);
else
    if isfield(source,'schemaVersion'), plotData = source;
    else, plotData = leo_collect_plot_data(source); end
    specs = leo_build_plot_specs(plotData);
end
files = {}; figures = {};
if render, [files,figures] = leo_render_plot_specs(specs,directory,saveFiles); end
end

function leo_export_benchmark(report,directory)
%LEO_EXPORT_BENCHMARK 导出实验 CSV/MAT 及全部可重画数值，包含迭代/价格/SB 能量日志。
% 输入：对比报告、目录；输出：目录内文件，无函数句柄序列化依赖。
if ~exist(directory,'dir'), mkdir(directory); end
leo_write_struct_csv(fullfile(directory,'runs.csv'),report.records);
leo_write_struct_csv(fullfile(directory,'summary.csv'),report.summary);
completed = sum(strcmp({report.records.status},'completed'));
K = report.problemData.shape(1); M = report.problemData.shape(2);
userTemplate = struct('method','','seed',0,'user',0, ...
    'targetBits',0,'serviceBits',0,'demandRatio',0);
scheduleTemplate = struct('method','','seed',0,'user',0,'resource',0, ...
    'selected',false,'beam',0);
users = repmat(userTemplate,completed*K,1);
schedule = repmat(scheduleTemplate,completed*K*M,1);
uIndex = 0; gIndex = 0;
for r = 1:numel(report.records)
    if ~strcmp(report.records(r).status,'completed'), continue; end
    result = report.solutions{r}; row = report.records(r);
    for i = 1:K
        u = struct('method',row.method,'seed',row.seed,'user',i, ...
            'targetBits',report.problemData.qosTargetBits(i),'serviceBits',result.service.userBits(i), ...
            'demandRatio',result.service.demandRatio(i));
        uIndex = uIndex+1; users(uIndex) = u;
        for m = 1:M
            g = struct('method',row.method,'seed',row.seed,'user',i,'resource',m, ...
                'selected',logical(result.x(i,m)),'beam',report.problemData.beamIndex(i,m));
            gIndex = gIndex+1; schedule(gIndex) = g;
        end
    end
end
assert(uIndex==numel(users) && gIndex==numel(schedule));
leo_write_struct_csv(fullfile(directory,'user_service.csv'),users);
leo_write_struct_csv(fullfile(directory,'schedules.csv'),schedule);
save(fullfile(directory,'benchmark.mat'),'report','-v7');
leo_export_plot_data(report,directory); % 主入口只在 saveResults=true 时调用显式导出。
end

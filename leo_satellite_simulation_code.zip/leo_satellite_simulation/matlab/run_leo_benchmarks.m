function [report,figures] = run_leo_benchmarks(caseOrParameters,overrides)
%RUN_LEO_BENCHMARKS 文档第 13.3 节统一对比主入口，固定 32 波束/最多 8 人。
% 输入：'default'(默认 32用户/20块)、'small'(8用户/3块)或自定义参数；可选实验覆盖。
% 输出：report 数值报告、figures 图窗句柄 cell。默认显示 18 图、不保存、不穷举。
% 仅显式设置 saveResults=true 才导出 CSV/MAT/JSON/PNG/PDF/FIG。
if nargin<1, caseOrParameters = 'default'; end
if nargin<2, overrides = struct(); end
options = leo_benchmark_options(overrides);
if isstruct(caseOrParameters)
    p = caseOrParameters; caseName = 'custom';
else
    caseName = caseOrParameters; p = leo_default_parameters();
    assert(any(strcmp(caseName,{'small','default'})));
    if strcmp(caseName,'small'), p.system.K = 8; p.time.nSlots = 15; end
end
p.method.enabled = false; p.exhaustive.enabled = false;
model = run_leo_sinr(p);
report = leo_benchmark_case(model,options);
report.caseName = caseName;
directory = '';
if options.saveResults
    directory = options.outputDirectory;
    if isempty(directory), directory = fullfile('results',['benchmark_',caseName]); end
end
report.outputDirectory = directory;
report.plotStatus = 'disabled';
report.plotFiles = {}; figures = {};
plotSource = report;
if options.saveResults
    leo_export_benchmark(report,directory);
    plotSource = fullfile(directory,'plot_data.mat');
end
if options.makePlots
    try
        [report.plotFiles,~,figures] = run_leo_plot_results(plotSource,directory,true,options.saveResults);
        report.plotStatus = 'completed';
    catch err
        report.plotStatus = ['unavailable: ',err.message];
        warning('leo:plotUnavailable','图窗未全部生成；数值结果仍在返回变量 report 中: %s',err.message);
    end
end
if options.saveResults, save(fullfile(directory,'benchmark.mat'),'report','-v7'); end
end

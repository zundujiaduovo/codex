function rows = leo_append_struct(rows,item)
%LEO_APPEND_STRUCT 将标量结构体加入可能尚无字段的结构体数组，兼容 MATLAB。
% 输入：rows：结构体数组，可为 struct([])；item：字段相同的标量结构体。
% 输出：rows：追加 item 后的列结构体数组。
assert(isstruct(rows) && isstruct(item) && isscalar(item));
if isempty(rows)
    rows = item;
else
    rows(end+1,1) = item;
end
end

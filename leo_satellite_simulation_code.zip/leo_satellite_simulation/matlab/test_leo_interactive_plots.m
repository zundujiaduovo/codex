function test_leo_interactive_plots()
%TEST_LEO_INTERACTIVE_PLOTS 检查 32 用户入口默认不保存，以及图窗可见并在返回后保留。
% 接口标注：
% 输入：无；构造独立数值基准及边界算例。
% 输出：无返回值；失败时抛出断言，成功时打印检查组数。
% 输入：无；输出：通过/跳过组数；无图形后端时明确跳过图窗检查。
checks = 0; skipped = 0;
o = leo_benchmark_options();
assert(o.makePlots && ~o.saveResults && ~o.exhaustive);
directory = tempname;
cleanup = onCleanup(@() remove_directory(directory)); %#ok<NASGU>
[report,figures] = run_leo_benchmarks('default',struct('methods',{{'initial'}}, ...
    'seeds',13,'makePlots',false,'verbose',false,'outputDirectory',directory));
assert(report.parameters.system.K==32 && report.parameters.system.maxStreams==8);
assert(report.parameters.array.nBeams==32 && report.problemData.shape(2)==20);
assert(isempty(report.exhaustive) && isempty(report.outputDirectory));
assert(isempty(figures) && isempty(report.plotFiles) && exist(directory,'dir')==0);
checks = checks+1;

if exist('OCTAVE_VERSION','builtin') && isempty(available_graphics_toolkits())
    fprintf('SKIP: visible persistent figures (no graphics toolkit).\n');
    skipped = skipped+1;
else
    previous = findall(0,'Type','figure'); previousVisible = get(0,'DefaultFigureVisible');
    graphicsCleanup = onCleanup(@() restore_figures(previous,previousVisible)); %#ok<NASGU>
    set(0,'DefaultFigureVisible','off'); % 函数须显式显示，不能受隐藏图窗偏好影响。
    data = leo_collect_plot_data(report); specs = leo_build_plot_specs(data);
    [files,figures] = leo_render_plot_specs(specs([1,11]),directory);
    assert(isempty(files) && numel(figures)==2 && exist(directory,'dir')==0);
    drawnow;
    for j = 1:numel(figures)
        assert(ishandle(figures{j}) && strcmp(get(figures{j},'Visible'),'on'));
        assert(strcmp(get(figures{j},'WindowStyle'),'normal'));
        assert(~isempty(findall(figures{j},'Type','axes')));
    end
    checks = checks+1;
end
fprintf('PASS: %d interactive/default-output test groups; SKIP: %d.\n',checks,skipped);
end

function restore_figures(previous,visible)
set(0,'DefaultFigureVisible',visible);
current = findall(0,'Type','figure');
for h = current(:).'
    if ~any(h==previous), close(h); end
end
end

function remove_directory(directory)
if exist(directory,'dir'), rmdir(directory,'s'); end
end

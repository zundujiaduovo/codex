% SHOW_32USER_PLOTS 直接弹出包内已有的 32 用户实验图；不重新求解、不保存文件。
% 在 MATLAB 中打开本文件并点“运行”。新实验使用同目录 main_32users.m。
leoProjectDir = fileparts(mfilename('fullpath'));
addpath(fullfile(leoProjectDir,'matlab'));
[plotFiles,plotData,figures] = run_leo_plot_results( ...
    fullfile(leoProjectDir,'examples','plots_default','plot_data.mat'));
fprintf('已有 32 用户结果：已打开 %d 个图窗，数值在 plotData 中。\n',numel(figures));
